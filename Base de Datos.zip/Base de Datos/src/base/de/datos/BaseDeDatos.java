
package base.de.datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;


public class BaseDeDatos {

    Connection conex;
    public static void main(String[] args) {
       BaseDeDatos objeto = new BaseDeDatos();
       objeto.conectar();
       //objeto.crea_bd();
       //objeto.crea_tabla();
       //objeto.insertar("2018", "Kevin", 2.80f, 2.80f, 2.80f);
       //objeto.listar();
       //objeto.desconectar();
    }
    
    
    //Conexion a MySQL de manera local
    void conectar(){
        //usamos una excepcion try-catch en caso de presetnar inconvenientes al conectar
        try{
            //objeto conex creado
            conex = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+"?useTimezone=true&serverTimezone=UTC", "root", "MySQL2018kevin_98");
        }
        catch(SQLException e){
            System.out.println("error1 ="+e.toString()); //porque se pasa a string?
        }
    }
    
    //cse cierra la base de datos para finalizar la modificacion en la misma
    void desconectar(){
        try{
            conex.close();
        }
        catch(SQLException e){
            System.out.println("error2 ="+e.toString());
        }
    }
    
    //se crea base de datos
    void crea_bd(){
        //argumento para crear
        String s="create database BaseU";
        
        //objeto para?
        java.sql.Statement st;
        
        try{
            st=conex.createStatement();
            st.executeUpdate(s);
        }
        catch(SQLException e){
            System.out.println("error3 ="+e.toString());
        }
    }
    
    //Con la base de datos lista, se crea una tabla para la base de datos
    void crea_tabla(){
        String s1 = "use BaseU";
        String s = "create table "+"DatosEstudiante"+"(cod varchar(11), nombre varchar(25), nota1 decimal(10,3), nota2 decimal(10,3), nota3 dec(10,3))";  
        java.sql.Statement st;
        
        try{
            st= conex.createStatement();
            st.executeUpdate(s1);
            st.executeUpdate(s);
        }
        catch(SQLException e){
            System.out.println("error4 ="+e.toString());
        }
    }
    
    
    // metodo para insertar datos dentro de la tabla en la base de datos
    void insertar(String cod, String nombre, float nota1, float nota2, float nota3){
        String s1 = "use BaseU";
        //los valores se reciben con parametros diferentes en java y en la base de datos, OJO nomenclaturqa ahi, comillas simples luego doble comilla
        String sql = "insert into DatosEstudiante"+"(cod,nombre,nota1,nota2,nota3)"+"values(' "+cod+" ',' "+nombre+" ',' "+nota1+" ',' "+nota2+" ',' "+nota3+" ')";
        java.sql.Statement st;
        
        try{
            st = conex.createStatement();
            st.executeLargeUpdate(s1);
            st.executeUpdate(sql);
        }
        catch(SQLException e){
            System.out.println("error5 ="+e.toString());
        }
    }
    
    //Listar, es generar la listas de lo que se encuentra en la base de datos
    void listar(){
        String s1="use BaseU";
        //argumento base de datos para ver la tabla
        String sql ="select * from DatosEstudiante";
        java.sql.Statement st;
        try{
            st= conex.createStatement();
            st.executeUpdate(s1);
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                System.out.println(rs.getString("cod"));
                System.out.println(rs.getString("nombre"));
                System.out.println(rs.getFloat("nota1"));
                System.out.println(rs.getFloat("nota2"));
                System.out.println(rs.getFloat("nota3"));
            }
        }
        catch(SQLException d){
            System.out.println("error6 ="+d.toString());
        }
    }
}
