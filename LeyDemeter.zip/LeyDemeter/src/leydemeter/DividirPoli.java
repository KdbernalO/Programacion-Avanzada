/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leydemeter;

/**
 *
 * @author estudiantes
 */
public class DividirPoli {
    
    public DividirPoli(int a, int b, int c, int d ){
        
        int divpos[]= new int [15];
        int divneg[]= new int [15];
        
       // for(int i)
    }
}
