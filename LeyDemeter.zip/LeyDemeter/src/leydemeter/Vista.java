
package leydemeter;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class Vista extends JFrame {
    
    JLabel mensaje = new JLabel("Raices polinomio grado 3 usando ley de DEMETER");
    JLabel a = new JLabel("a");
    JLabel b = new JLabel("b");
    JLabel c = new JLabel("c");
    JLabel d = new JLabel("d");
    JTextField a1 = new JTextField();
    JTextField b1 = new JTextField();
    JTextField c1 = new JTextField();
    JTextField d1 = new JTextField();
    JTextField resul = new JTextField();
    JButton raices = new JButton("Calcular Raices");
    
    public void mostrar (){
        setSize(700, 240);
        setVisible(true);
        setLayout(null);
        setResizable(false);
        setLocationRelativeTo(null);
        mensaje.setBounds(70, 10, 400, 35);
        a.setLocation(50, 50);
        b.setLocation(50, 70);
        c.setLocation(50, 90);
        d.setLocation(50, 110);
        a1.setBounds(70, 50, 100, 20);
        b1.setBounds(70, 70,100, 20);
        c1.setBounds(70, 90, 100, 20);
        d1.setBounds(70, 110, 100,20);
        resul.setBounds(250, 110, 100,20);
        raices.setLocation(70,150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    public Vista (){
        Container x = getContentPane();
        x.setLayout(new FlowLayout());
        x.add(a);
        x.add(b);
        x.add(c);
        x.add(d);
        x.add(a1);
        x.add(b1);
        x.add(c1);
        x.add(d1);
        x.add(mensaje);
        x.add(resul);
        x.add(raices);
        
    }
    
    public void oyente(Controlador c){
        raices.addActionListener(c);
    }
    
}
