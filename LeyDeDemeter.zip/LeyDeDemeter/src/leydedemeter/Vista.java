/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leydedemeter;

import java.awt.Container;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Vista extends JFrame {
    
    JButton calcular = new JButton("calcular");
    JTextField A = new JTextField();
    JTextField B = new JTextField();
    JTextField C = new JTextField();
    JTextField D = new JTextField();
    JLabel mensaje = new JLabel("Raices polinomio grado 3 usando ley de DEMETER");
    JLabel raiz1 = new JLabel("");
    JLabel raiz2 = new JLabel("");
    JLabel raiz3 = new JLabel("");
    JLabel x3 = new JLabel("X^3");
    JLabel x2 = new JLabel("X^2");
    JLabel x1 = new JLabel("X");
    JLabel ra1= new JLabel("Raiz 1");
    JLabel ra2 = new JLabel("Raiz 2");
    JLabel ra3 = new JLabel("Raiz 3");
    
     void Mostrar(){
        setSize(700,250);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        mensaje.setBounds(200, 20, 300, 20);
        A.setBounds(150,80, 30,20);
        x3.setBounds(190,80, 100, 20);
        B.setBounds(230, 80, 30, 20);
        x2.setBounds(270,80,100, 20);
        C.setBounds(310, 80, 30,20);
        x1.setBounds(350, 80, 100, 20);
        D.setBounds(380, 80,30,20);
        ra1.setBounds(150, 140, 80, 20);
        ra2.setBounds(230, 140, 80, 20);
        ra3.setBounds(310, 140, 80, 20);
        raiz1.setBounds(310, 180,100,20);
        raiz2.setBounds(230, 180,100,20);
        raiz3.setBounds(150, 180,100,20);
        calcular.setBounds(480,80,100, 20);
    }    
    
    Vista() {
        Container conte = getContentPane();
        conte.setLayout(null);
        conte.add(calcular);
        conte.add(calcular);
        conte.add(A);
        conte.add(B);
        conte.add(C);
        conte.add(D);
        conte.add(mensaje);
        conte.add(raiz1);
        conte.add(raiz2);
        conte.add(raiz3);
        conte.add(ra1);
        conte.add(ra2);
        conte.add(ra3);
        conte.add(x3);
        conte.add(x2);
        conte.add(x1); 
    }
    
      void Listener(Controlador contro){
        calcular.addActionListener(contro); 
    }
    
}
