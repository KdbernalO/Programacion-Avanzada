package leydedemeter;

public class Cuadratica {
    
    double raiz1;
    double raiz2;      
    
    Cuadratica(int a, int b, int c){
        raiz1=(-b+Math.sqrt((b*b)-4*a*c))/(2*a);
        raiz2=(-b-Math.sqrt((b*b)-4*a*c))/(2*a);
    }
}
