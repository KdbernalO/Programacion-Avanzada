 package leydedemeter;
public class Main {

    public static void main(String[] args) {
        
        PrimeraRaiz p = new PrimeraRaiz();
        Vista v= new Vista();
        Controlador c = new Controlador(v, p);
        v.Listener(c);
        v.Mostrar();
        
    }
    
}
