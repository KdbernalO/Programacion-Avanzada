package leydedemeter;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class PrimeraRaiz {

    int cuadra;
    int uno;
    int indepen;
    int raiz;
    Cuadratica cua; 
    
    PrimeraRaiz() {
    }

    void Calcular(int a, int b, int c, int d) {
        
        ArrayList<Integer> coeficientes= new ArrayList();
        int aux;
        int calcu1;
        int calcu2;
        int calcu3;
        int calcu4;
        for (int i=-1*(Math.abs(d)); i <=Math.abs(d) ; i++) {
            if (i!=0 && (d%i)==0)
            coeficientes.add(i);
        }

        for (int j = 0; j < coeficientes.size(); j++) {
            calcu1 = a * coeficientes.get(j);
            cuadra = a;
            calcu2 = b + calcu1;
            uno = calcu2;
            calcu2 *= coeficientes.get(j);
            calcu3 = c + calcu2;
            indepen = calcu3;
            calcu3 *= coeficientes.get(j);
            calcu4 = d + calcu3;
            aux = calcu4;
            if (aux == 0) {
                raiz = coeficientes.get(j);
                j=coeficientes.size()+1;
            }

        }

    }
    
    void Cuadra(){
        cua = new Cuadratica(cuadra, uno, indepen);
    }

    public Cuadratica getCua() {
        return cua;
    }
    
    

}
