package leydedemeter;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class Controlador implements ActionListener {

    Vista vista;
    PrimeraRaiz p;
    
    Controlador(Vista b, PrimeraRaiz x){
        this.vista= b;
        this.p= x;
    }
    
    @Override
    public void actionPerformed(ActionEvent ae){
       try{
        p.Calcular(Integer.parseInt(vista.A.getText()),Integer.parseInt(vista.B.getText()),Integer.parseInt(vista.C.getText()),Integer.parseInt(vista.D.getText()));
        p.Cuadra();
        vista.raiz1.setText(Integer.toString(p.raiz));
        vista.raiz2.setText(Double.toString(p.getCua().raiz1));
        vista.raiz3.setText(Double.toString(p.getCua().raiz2));}
       catch(NumberFormatException nfe){
           JOptionPane.showMessageDialog(null,"Inserte valores validos");
       }
    }
    
    
    
}
