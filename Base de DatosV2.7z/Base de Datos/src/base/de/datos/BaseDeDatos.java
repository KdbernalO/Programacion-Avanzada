
package base.de.datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class BaseDeDatos {

    Connection conex;
    public static void main(String[] args) {
       Interfaz ventana=new Interfaz();
       }
    
    
    //Conexion a MySQL de manera local
    void conectar(){
        //usamos una excepcion try-catch en caso de presetnar inconvenientes al conectar
        try{
            //objeto conex creado
            conex = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+"?useTimezone=true&serverTimezone=UTC", "root", "mysql2019");
            JOptionPane.showMessageDialog(null, "Se ha conectado con exito!","Conectado",2);
        }
        catch(SQLException e){
            System.out.println("error1 ="+e.toString()); //porque se pasa a string?
        }
    }
    
    //cse cierra la base de datos para finalizar la modificacion en la misma
    void desconectar(){
        try{
            conex.close();
            JOptionPane.showMessageDialog(null, "Se ha desconectado con exito!","Desconectado",2);
        }
        catch(SQLException e){
            System.out.println("error2 ="+e.toString());
        }
    }
    
    //se crea base de datos
    void crea_bd(String nombre){
        //argumento para crear
        String s="create database "+ nombre;
        
        //objeto para?
        java.sql.Statement st;
        
        try{
            st=conex.createStatement();
            st.executeUpdate(s);
            JOptionPane.showMessageDialog(null, "Se ha creado la base de datos "+nombre+" con exito!","Base",2);
        }
        catch(SQLException e){
            System.out.println("error3 ="+e.toString());
        }
    }
    
    //Con la base de datos lista, se crea una tabla para la base de datos
    void crea_tabla(String nombrebs,String nombretb){
        String s1 = "use "+nombrebs;
        String s = "create table "+nombretb+"(cod varchar(11), nombre varchar(25), nota1 decimal(10,3), nota2 decimal(10,3), nota3 dec(10,3), promedio decimal(10,3))";  
        java.sql.Statement st;
        
        try{
            st= conex.createStatement();
            st.executeUpdate(s1);
            st.executeUpdate(s);
            
        }
        catch(SQLException e){
            System.out.println("error4 ="+e.toString());
        }
    }
    
    
    // metodo para insertar datos dentro de la tabla en la base de datos
    void insertar(String nombreBs, String nombreTb, String cod, String nombre, float nota1, float nota2, float nota3){
        String s1 = "use " + nombreBs;
        
        float aux = calcularPromedio(nota1, nota2, nota3);
        
        //los valores se reciben con parametros diferentes en java y en la base de datos, OJO nomenclaturqa ahi, comillas simples luego doble comilla
        String sql = "insert into "+ nombreTb+"(cod,nombre,nota1,nota2,nota3,promedio)"+"values(' "+cod+" ',' "+nombre+" ',' "+nota1+" ',' "+nota2+" ',' "+nota3+" ', ' "+aux+" ')";
        java.sql.Statement st;
        
        try{
            st = conex.createStatement();
            st.executeUpdate(s1);
            st.executeUpdate(sql);
        }
        catch(SQLException e){
            System.out.println("error5 ="+e.toString());
        }
    }
    
    //Listar, es generar la listas de lo que se encuentra en la base de datos
    void listar(){
        String s1="use BaseU";
        //argumento base de datos para ver la tabla
        String sql ="select * from DatosEstudiante";
        java.sql.Statement st;
        try{
            st= conex.createStatement();
            st.executeUpdate(s1);
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                System.out.println(rs.getString("cod"));
                System.out.println(rs.getString("nombre"));
                System.out.println(rs.getFloat("nota1"));
                System.out.println(rs.getFloat("nota2"));
                System.out.println(rs.getFloat("nota3"));
            }
        }
        catch(SQLException d){
            System.out.println("error6 ="+d.toString());
        }
    }
    
    public float calcularPromedio(float nota1, float nota2, float nota3){
        return (nota1+nota2+nota3)/3;
    }
}
