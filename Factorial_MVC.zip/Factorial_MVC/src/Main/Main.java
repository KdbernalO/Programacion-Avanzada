
package Main;

import mvc.Controlador;
import mvc.Modelo;
import mvc.Vista;


public class Main {
    
    public static void main(String[] args) {
        
        Modelo m= new Modelo();
        Vista v = new Vista();
        Controlador u = new Controlador(v,m);
        v.asignaOyente(u);
        v.mostrar();
    }
}
