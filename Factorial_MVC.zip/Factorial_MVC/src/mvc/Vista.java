
package mvc;

import java.awt.Container;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class Vista extends JFrame {
    
    JLabel l1 = new JLabel("Numero factorial a calcular");
    JLabel l2 = new JLabel();//Muestra el resultado del factorial
    JLabel l3 = new JLabel();
    JTextField inum = new JTextField();//Capta el numero ingresado
    JButton bMostrar = new JButton("Calcular Factorial");
    
    public void mostrar(){
        setSize(700, 200);
        setVisible(true);
        setLayout(null);
        setResizable(false);
        setLocationRelativeTo(null);
        l1.setLocation(50, 10);
        l2.setBounds(350,50,30,35);
        l3.setBounds(350,10,120,35);
        inum.setBounds(50,45,130,35);
        bMostrar.setLocation(50, 100);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    public Vista(){
        Container c = getContentPane();
        c.setLayout(new FlowLayout());
        c.add(l1);
        c.add(inum);
        c.add(bMostrar);
        c.add(l2);
        c.add(l3);
    }
    public void asignaOyente(Controlador c){
     bMostrar.addActionListener(c);
     inum.addKeyListener(c);
    }
}
