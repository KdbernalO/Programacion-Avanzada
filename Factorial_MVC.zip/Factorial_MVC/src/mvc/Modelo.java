
package mvc;

public class Modelo {
   
    
    public int factorial(int num){
        int fac=1;
        for(int i=1 ; i<=num ; i++){
            if(num==0){
                fac=1;
            }else{
                fac*=i;    
            }
        }
        return fac;
    }
}
