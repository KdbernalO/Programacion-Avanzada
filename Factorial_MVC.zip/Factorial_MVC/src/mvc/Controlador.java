
package mvc;


import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JOptionPane;



public class Controlador implements ActionListener, KeyListener {

    Vista v;
    Modelo m;
    int mem;
    
    public Controlador(Vista v, Modelo m){
        this.v=v;
        this.m=m;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
       String s = v.inum.getText();
       int x = Integer.parseInt(s);
       mem= m.factorial(x);
       v.l2.setText(Integer.toString(mem));
       v.l3.setText("El factorial de " + s + " es: ");
   }   

    @Override
    public void keyTyped(KeyEvent e) {
       if(!Character.isDigit(e.getKeyChar())){
           e.consume();
           JOptionPane.showMessageDialog(null, "Digite un numero entero");
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }

}
